<?php
    $_product_key_honda = '2163ef55-5db0-4300-ba58-ea4303df5f46';
	$_product_key_yamaha = '324d31df-d5ab-4449-85a7-43e5a97c3e28';
?>